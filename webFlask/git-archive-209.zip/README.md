# ai_mnist_web  
AI cnn  flask WEB Develop  

노트북 사양 : 한성노트북 bossmonster x34 

cpu : i7-4702mq 

mem : 8g 

gpu : nvidia geforce gtx765m 대략 성능은 최저기준에 맞춤 3.5 

flask web  programming 

python으로 개발 

dataset : MNIST를 학습 

javascript로 캔버스 프로그래밍 

AI 알고리즘 : CNN(합성곱) 

대략 정확도는 80% 정도 일치 

동영상 

https://drive.google.com/file/d/1voPSNL0U3_W7ck240mAoM2wtWsQudg-g/view
